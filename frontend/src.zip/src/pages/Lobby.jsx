import { useEffect, useRef, useState } from "react"
import { useNavigate, useParams, useSearchParams } from "react-router-dom"
import { HostAvatar, PlayerAvatar } from "../components/CyberAvatar"
import { API_BASE_URL, WS_BASE_URL } from "../config/api"
import SockJS from "sockjs-client"
import Stomp from 'stompjs'

function Lobby() {
    const navigate = useNavigate()
    const { roomCode } = useParams()
    const [searchParams] = useSearchParams()
    const nickName = searchParams.get('nickname') || 'Player'
    const isHost = searchParams.get('host') === 'true'
    const isHostPlaying = searchParams.get('playing') === 'true'
    const defaultCategory = { id: 'general', label: '⚔️ General Arena', icon: '⚔️' }

    const [connected, setConnected] = useState(false)
    const [copied, setCopied] = useState(false)
    const [players, setPlayers] = useState([])
    const [errorMessage, setErrorMessage] = useState('')

    const [quizId, setQuizId] = useState(-1)
    const [quizTitle, setQuizTitle] = useState('')
    const [quizDescription, setQuizDescription] = useState('')
    const [questionCount, setQuestionCount] = useState(0)
    const [quizQuestions, setQuizQuestions] = useState([])
    const [quizTriviaFacts, setQuizTriviaFacts] = useState([])
    const [quizConcepts , setQuizConcepts] = useState([])
    const [quizCategory, setQuizCategory] = useState(defaultCategory)

    const [chatMessages, setChatMessages] = useState([
        { sender: 'Arena Master', text: 'Welcome champions to the QuizArena battle lobby!', isSystem: true }
    ])
    const [chatInput, setChatInput] = useState('')
    const [chatMinimized, setChatMinimized] = useState(false)

    const stompClient = useRef(null)

    useEffect(() => {
        fetch(`${API_BASE_URL}/api/rooms/${roomCode}`)
            .then(res => res.json())
            .then((roomInfo) => {
                if (roomInfo === null) {
                    navigate("/")
                } else {
                    setPlayers(roomInfo.players || [])

                    fetch(`${API_BASE_URL}/api/quizzes/${roomInfo.quizId}`)
                    .then(res => {
                        if (!res.ok) return null
                        return res.json()
                    })
                    .then((quizInfo) => {
                        if (quizInfo == null) {
                            console.log(`No quiz found with Id ${roomInfo.quizId}`)
                            navigate("/")
                            return
                        }
                        setQuizId(roomInfo.quizId)
                        setQuizTitle(quizInfo.title)
                        setQuizDescription(quizInfo.description)
                        setQuestionCount(quizInfo.questions?.length || 0)
                        setQuizQuestions(quizInfo.questions || [])
                        setQuizConcepts(quizInfo.concepts || [])
                        setQuizTriviaFacts(quizInfo.triviaFacts || []) 
                        setQuizCategory(quizInfo.category || defaultCategory)
                        // Set the Icon as well.
                    })

                }
            })
            .catch(err => console.log(err))

        const socket = new SockJS(WS_BASE_URL)
        const client = Stomp.over(socket)
        client.debug = null
        client.connect({}, () => {
            stompClient.current = client
            setConnected(true)

            client.subscribe(`/topic/rooms/${roomCode}/waiting`, (msg) => {
                const data = JSON.parse(msg.body)
                if (data && data.players) {
                    setPlayers(data.players)
                }
            })

            client.subscribe(`/topic/rooms/${roomCode}/players/${nickName}`, (msg) => {
                const data = JSON.parse(msg.body)
                setErrorMessage(data.message)
            })

            client.subscribe(`/topic/rooms/${roomCode}/start`, () => {
                client.disconnect()
                navigate(`/rooms/${roomCode}?nickname=${nickName}`)
            })
        }, () => {
            setConnected(false)
        })

        return () => {
            if (stompClient.current) stompClient.current.disconnect()
        }
    }, [roomCode, nickName, navigate])

    function startGame() {
        if (!connected) {
            setErrorMessage("Not connected to server. Try refreshing.")
            return
        }
        setErrorMessage('')
        if (stompClient.current) {
            stompClient.current.send("/app/game/rooms/start", {}, JSON.stringify({
                roomCode: roomCode,
                hostNickName: nickName
            }))
        }
    }

    function handleSendChat(e) {
        e.preventDefault()
        if (!chatInput.trim()) return

        const newMsg = { sender: nickName, text: chatInput.trim() }
        setChatMessages(prev => [...prev, newMsg])
        setChatInput('')
    }

    function copyCodeToClipboard() {
        navigator.clipboard.writeText(roomCode)
        setCopied(true)
        setTimeout(() => setCopied(false), 2000)
    }

    function leaveRoom(){
        if (stompClient.current) {
            stompClient.current.send("/app/game/rooms/leave", {}, JSON.stringify({
                roomCode: roomCode,
                playerNickName: nickName
            }))
        }
        navigate("/")
    }

    const hostPlayer = (players && players.length > 0) ? players[0] : { nickName: isHost ? nickName : 'Host' }
    const otherPlayers = (players && players.length > 1) ? players.slice(1) : []

    const totalSegments = 14
    const filledSegments = Math.min(totalSegments, Math.max(0, Math.floor(((players?.length || 0) / 2) * (totalSegments / 2))))

    return (
        <div className="min-h-screen bg-[#0A0E1A] text-[#F9FAFB] py-4 px-4 sm:px-6 flex flex-col items-center justify-center">
            <div className="w-full max-w-[1440px] mx-auto space-y-4">
            <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                    <span className="text-xs sm:text-sm font-semibold tracking-wider text-gray-300 flex items-center gap-1.5 bg-[#111827] border border-gray-800 rounded-xl px-3 py-1.5">
                        <span>⚔️</span> <span className="text-[#F9FAFB]">QUIZ</span>ARENA LOBBY
                    </span>
                </div>

                <div className="flex items-center gap-2 sm:gap-3">
                    <div className="flex items-center gap-2 bg-[#111827] border border-gray-800 rounded-xl px-3 py-1">
                        <PlayerAvatar name={nickName} className="w-7 h-7" />
                        <span className="text-xs font-bold text-slate-200">{nickName}</span>
                    </div>

                    <button
                        onClick={leaveRoom}
                        title="Leave Battle Lobby"
                        className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gray-800 hover:bg-gray-700 border border-gray-700 text-gray-300 hover:text-white text-xs font-bold transition-all cursor-pointer"
                    >
                        <span>🚪</span>
                        <span className="hidden sm:inline">Leave</span>
                    </button>
                </div>
            </div>

            <div className="w-full max-w-[1440px] mx-auto grid grid-cols-1 md:grid-cols-3 gap-4 items-stretch">
    
                <div className="bg-[#111827] border border-gray-800 rounded-2xl p-4 sm:p-5 flex flex-col justify-between">
                    <div className="flex flex-col items-center justify-center p-4 bg-[#0A0E1A] border border-gray-800 rounded-xl gap-1.5 text-center relative overflow-hidden">
                        <div className="flex items-center justify-between mb-2">
                            <span className="text-xs uppercase tracking-widest font-bold text-gray-400">Room Code</span>
                            <div className="flex items-center gap-1.5">
                                <span className={`w-2 h-2 rounded-full ${connected ? 'bg-emerald-400 animate-pulse' : 'bg-rose-500'}`} />
                                <span className="text-[11px] font-semibold text-emerald-400">{connected ? 'Connected' : 'Offline'}</span>
                            </div>
                        </div>

                        <div 
                            onClick={copyCodeToClipboard}
                            title="Click to copy room code"
                            className="cursor-pointer group py-1"
                        >
                            <h2 className="font-mono tracking-[0.25em] text-3xl sm:text-4xl font-extrabold text-amber-400">
                                {roomCode}
                            </h2>
                            <p className="text-[10px] text-slate-400 group-hover:text-slate-200 mt-1">
                                {copied ? '✅ Copied to clipboard!' : '📋 Click to copy code'}
                            </p>
                        </div>
                    </div>

                    <div className="bg-[#111827] border border-gray-800 rounded-2xl p-4 flex flex-col justify-between flex-grow">
                        <div>
                            <div className="flex items-center justify-between mb-4">
                                <span className="text-xs font-semibold px-2.5 py-1 rounded-md bg-gray-800 text-amber-400 border border-gray-700/60">
                                    {questionCount} Questions
                                </span>
                                {/* 🏷️ CATEGORY BADGE */}
                                <span className="text-xs font-semibold px-2.5 py-1 rounded-md bg-gray-800 text-sky-400 border border-gray-700/60">
                                    {quizCategory?.label || '⚔️ General Arena'}
                                </span>
                            </div>

                            <div className="w-full h-24 rounded-xl bg-[#0A0E1A] border border-gray-800 flex items-center justify-center p-3 relative overflow-hidden mb-3">
                                <div className="text-5xl">
                                    {quizCategory.icon}
                                </div>
                            </div>

                            <h3 className="text-xl font-extrabold text-white leading-tight">{quizTitle || 'Loading Quiz...'}</h3>
                            <p className="text-xs text-gray-400 mt-1 mb-4">{quizDescription || 'Test your knowledge in the arena'}</p>

                            <div className="border-t border-slate-800 pt-3">
                                <p className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-2">Key concepts</p>
                                <ul className="text-xs text-slate-300 space-y-1.5">
                                    {quizConcepts.map((c, idx) => (
                                        <li key={idx} className="flex items-center gap-2">
                                            <span className={`w-1.5 h-1.5 rounded-full ${
                                                idx % 4 === 0 ? 'bg-amber-400' :
                                                idx % 4 === 1 ? 'bg-sky-400' :
                                                idx % 4 === 2 ? 'bg-emerald-400' : 'bg-gray-400'
                                            }`} />
                                            <span className="truncate">{c?.concept}</span>
                                        </li>
                                    ))}
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="bg-[#111827] border border-gray-800 rounded-2xl p-4 sm:p-5 flex flex-col justify-between">
                    
                    <div className="flex flex-col items-center relative w-full pt-2">
                        <HostAvatar className="w-20 h-20" />
                        <h3 className="text-xl font-bold text-[#F9FAFB] tracking-wide mt-1">
                            {hostPlayer?.nickName || 'Host'}
                        </h3>
                        <span className="text-xs font-semibold px-2 py-0.5 rounded bg-amber-500/10 text-amber-400 border border-amber-500/20 mt-1">
                            HOST
                        </span>
                    </div>

                    <div className="w-full my-4">
                        <p className="text-xs font-bold text-center tracking-wider text-gray-400 uppercase mb-3">
                            Waiting for players: at least 2 needed
                        </p>
                        <div className="text-xs font-semibold text-gray-400 bg-[#0A0E1A] border border-gray-800 px-3 py-1.5 rounded-lg inline-flex items-center gap-2 mb-6">
                            <span className="w-2 h-2 rounded-full bg-emerald-500" />
                            <span>Waiting for players ({players.length}/2 minimum)</span>
                        </div>

                        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 my-3 w-full">
                            {otherPlayers.map((p, idx) => (
                                <div key={idx} className="bg-[#0A0E1A] border border-gray-800 rounded-xl p-3 flex flex-col items-center justify-center gap-1.5 text-center">
                                    <PlayerAvatar index={idx + 1} name={p?.nickName || `Player ${idx + 1}`} className="w-10 h-10" />
                                    <span 
                                        title={p?.nickName || `Player ${idx + 1}`}
                                        className="text-xs font-semibold px-2 py-0.5 rounded bg-amber-500/10 text-amber-400 border border-amber-500/20 truncate max-w-[90px] text-center"
                                    >
                                        {p?.nickName || `Player ${idx + 1}`}
                                    </span>
                                </div>
                            ))}

                            {Array.from({ length: Math.max(0, 3 - otherPlayers.length) }).map((_, idx) => (
                                <div key={`empty-${idx}`} className="border border-dashed border-gray-800 rounded-xl p-3 flex flex-col items-center justify-center gap-1.5 text-gray-600 text-xs">
                                    <div className="w-10 h-10 rounded-xl border border-dashed border-gray-800 flex items-center justify-center text-gray-600 text-xl font-bold">
                                        +
                                    </div>
                                    <span className="text-[11px] text-slate-500 mt-2">Open Slot</span>
                                </div>
                            ))}
                        </div>
                    </div>

                    <div className="w-full flex flex-col items-center mt-auto">

                        {isHost ? (
                            <button
                                onClick={startGame}
                                disabled={players.length < 2}
                                className={`w-full bg-amber-500 hover:bg-amber-400 active:scale-[0.98] text-gray-950 font-bold py-3 rounded-xl transition-all shadow-md mt-auto ${
                                    players.length < 2
                                        ? 'bg-slate-800 text-slate-500 border border-slate-700 cursor-not-allowed'
                                    : ''
                                }`}
                            >
                                START GAME
                            </button>
                        ) : (
                            <div className="w-full py-4 rounded-xl bg-slate-800/80 border border-slate-700 text-center font-bold text-slate-300 text-sm tracking-wide animate-pulse">
                                Waiting for Host to Start...
                            </div>
                        )}

                        <span className="text-[11px] font-extrabold tracking-widest text-slate-500 uppercase mt-3">
                            WAITING FOR PLAYERS...
                        </span>
                    </div>
                </div>

                <div className="flex flex-col gap-5">
                    
                    <div className="bg-[#111827] border border-gray-800 rounded-2xl p-4 sm:p-5 flex flex-col justify-between">
                        <div className="flex items-center justify-between mb-3 border-b border-slate-800 pb-2">
                            <span className="text-xs font-extrabold tracking-wider uppercase text-gray-300 flex items-center gap-1.5">
                                <span>💡</span> Trivia Ticker ({quizTitle || 'Arena'})
                            </span>
                        </div>

                        <div className="space-y-2 overflow-y-auto max-h-40 pr-1">
                            {quizTriviaFacts.map((fact, idx) => (
                                <div key={idx} className="bg-[#0A0E1A] border border-gray-800 rounded-xl p-2.5 flex items-start gap-2.5 hover:border-gray-700 transition-colors">
                                    <span className="text-lg shrink-0 mt-0.5">{fact.icon}</span>
                                    <div>
                                        <h4 className="text-[11px] font-bold text-[#F9FAFB]">{fact.title}</h4>
                                        <p className="text-[11px] text-slate-300 leading-snug mt-0.5">{fact.text}</p>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>

                    <div className="bg-[#111827] border border-gray-800 rounded-2xl p-5 shadow-xl flex flex-col flex-grow min-h-[160px]">
                        <div className="flex items-center justify-between mb-2 border-b border-slate-800 pb-2">
                            <div className="flex items-center gap-2 text-xs font-bold text-emerald-400">
                                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                                <span>Lobby Chat</span>
                            </div>
                            <button
                                onClick={() => setChatMinimized(!chatMinimized)}
                                className="text-slate-400 hover:text-white text-xs font-bold"
                            >
                                {chatMinimized ? '➕' : '➖'}
                            </button>
                        </div>

                        {!chatMinimized && (
                            <>
                                <div className="flex-grow space-y-2 overflow-y-auto max-h-40 my-2 pr-1 text-xs">
                                    {chatMessages.map((msg, idx) => (
                                        <div key={idx} className={`rounded-lg p-2 ${msg.isSystem ? 'bg-[#0A0E1A] border border-gray-800 text-gray-300' : 'bg-[#0A0E1A] border border-gray-800 text-slate-200'}`}>
                                            <span className="font-bold text-amber-400 mr-1.5">{msg.sender}:</span>
                                            <span>{msg.text}</span>
                                        </div>
                                    ))}
                                </div>

                                <form onSubmit={handleSendChat} className="flex gap-2 mt-auto pt-2 border-t border-slate-800">
                                    <input
                                        type="text"
                                        placeholder="Chat with players..."
                                        value={chatInput}
                                        onChange={(e) => setChatInput(e.target.value)}
                                        className="flex-1 bg-[#0A0E1A] border border-gray-800 rounded-xl px-3 py-1.5 text-xs text-[#F9FAFB] placeholder-slate-500 focus:outline-none focus:border-amber-500"
                                    />
                                    <button
                                        type="submit"
                                        className="bg-amber-500 hover:bg-amber-400 text-gray-950 text-xs font-bold px-3 py-1.5 rounded-lg transition-colors"
                                    >
                                        ➤
                                    </button>
                                </form>
                            </>
                        )}
                    </div>
                </div>
            </div>

            </div>

            {errorMessage && (
                <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4">
                    <div className="bg-[#111827] border border-red-500/40 rounded-2xl p-6 w-full max-w-sm text-center shadow-2xl">
                        <p className="text-red-400 font-bold text-base mb-6">{errorMessage}</p>
                        <button
                            onClick={() => setErrorMessage('')}
                            className="bg-amber-500 hover:bg-amber-400 text-gray-950 px-8 py-2.5 rounded-xl font-bold transition-all"
                        >
                            OK
                        </button>
                    </div>
                </div>
            )}
        </div>
    )
}

export default Lobby
